<?php

namespace App\Http\Controllers;

use App\Banner;
use App\Cart;
use App\DeliverAdress;
use App\Order;
use App\OrderProduct;
use App\Product;
use App\ProductsAttribute;
use App\Traits\HeaderHelper;
use App\User;
use App\VendorOrder;
use Illuminate\Contracts\Session\Session as SessionSession;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;



class OrderController extends Controller
{
    use HeaderHelper;
    public function orderReview(Request $request){
        $user = User::where(['id'=>Auth::user()->id])->first();
        $shippingAddress = DeliverAdress::where(['user_id'=>Auth::user()->id])->first();
        $session_id = Session::get('session_id');
        $cartItems = Cart::where(['user_id'=>Auth::user()->id])->get();
        foreach($cartItems as $key=>$cart){
            $productDetails = Product::where(['id'=>$cart->product_id])->first();
            // echo "<pre>";print_r($productDetails);die;
            $cartItems[$key]->image = $productDetails->image;
            
        }
        //for header section categories for search and cart item for cart modal 
        $cartItems = $this->categoryItems();
        $categories = $this->categoryList();
        //end of header section
        return view('shop.order.order_review')->with(compact('cartItems','user','shippingAddress','categories'));
    }
    public function placeOrder(Request $request){
        if($request->isMethod('post')){
            $data = $request->all();
            if(!($request->has('paymentMethod'))){
                return redirect()->back()->with('flash_message_error','Please select payment method');
            }
            $user_id = Auth::user()->id;
            $user_email = Auth::user()->email;
            $user_name = Auth::user()->name;
            $shippingAddress = DeliverAdress::where(['user_id'=>$user_id])->first();
            //create order
            $order = new Order();
            if(empty(Session::get('CouponCode'))){
                $coupon_code = 'Not Used';
            }else{
                $coupon_code =Session::get('CouponCode');
            }
            if(empty(Session::get('CouponAmount'))){
                $coupon_amount = '0';
            }else{
                $coupon_amount =Session::get('CouponAmount');
            }
            $order->user_id = $user_id;
            $order->user_email = $user_email;
            $order->name = $user_name;
            $order->address = $shippingAddress->address;
            $order->phone = $shippingAddress->phone;
            $order->coupon_code = $coupon_code;
            $order->coupon_amount= $coupon_amount;
            $order->shipping_charges= $data['shipping_charges'];
            $order->order_status= "New";
            $order->payment_method = $data['paymentMethod'];
            $order->grand_total = $data['totalAmount'];
            $order->save();
            $order_id = DB::getPDO()->lastinsertId();
            // echo "<pre>";print_r($order_id);die;
           
            $cartItem = Cart::where(['user_id'=>$user_id])->get();
            foreach($cartItem as $product){

                $order_product = new OrderProduct();
                $order_product->order_id = $order_id;
                $order_product->user_id = $user_id;
                $order_product->product_id = $product->product_id;
                $order_product->product_name = $product->product_name;
                $order_product->product_code = $product->product_code;
                $order_product->product_color = $product->product_color;
                $order_product->product_price = $product->product_price;
                $order_product->product_size = $product->product_size;
                $order_product->product_qty = $product->product_quantity;
                $order_product->save();
                $order_product_id = DB::getPDO()->lastinsertId();
                $vendor_order = new VendorOrder();
                $vendor_order->order_id = $order_id;
                $vendor_order->owner_id = $product->product_owner_id;
                $vendor_order->order_product_id = $order_product_id;
                $vendor_order->save();
                $proArr = explode("--",$product->product_size);
                $productAttribute =  ProductsAttribute::where(['size'=>$proArr[1],'product_id'=>$product->product_id])->first();
                $updateQunatity = $productAttribute->stock - $product->product_quantity; 
                ProductsAttribute::where(['size'=>$proArr[1],'product_id'=>$product->product_id])->update(['stock'=>$updateQunatity]);
            }
            
            Session::put('order_id',$order_id);
            Session::put('grand_total',$data['totalAmount']);
           return redirect('/thanks');
            
        }
    }
    public function thanks(){
        $user_id = Auth::user()->id;
        Cart::where(['user_id'=>$user_id])->delete();
         //for header section categories for search and cart item for cart modal 
         $cartItems = $this->categoryItems();
         $categories = $this->categoryList();
         //end of header section
        return view('shop.order.thanks')->with(compact('cartItems','categories'));
    }
    public function userOrders(){
         //for header section categories for search and cart item for cart modal 
         $cartItems = $this->categoryItems();
         $categories = $this->categoryList();
         //end of header section
        $user_id = Auth::user()->id;
        $orders = Order::with('products')->where(['user_id'=>$user_id])->orderBy('id','desc')->get();
        return view('auth.orders')->with(compact('orders','categories','cartItems'));
    }
    public function userOrdersDetails($order_id){
         //for header section categories for search and cart item for cart modal 
         $cartItems = $this->categoryItems();
         $categories = $this->categoryList();
         //end of header section
        $orders = Order::with('products')->where(['id'=>$order_id])->orderBy('id','desc')->first();
        return view('auth.orders_details')->with(compact('orders','categories','cartItems'));
    }
    public function adminOrders(){
        $orders = Order::with('products')->get();
        return view('admin.orders.orders_view')->with(compact('orders'));
    }
    public function adminOrdersDetails($order_id){
        $orders = Order::with('products')->where(['id'=>$order_id])->orderBy('id','desc')->first();
        $user_id= $orders->user_id;
        $userDetails = User::where(['id'=>$user_id])->first();
        $shippingAddress = DeliverAdress::where(['user_id'=>$user_id])->first();
        return view('admin.orders.orders_details')->with(compact('orders','userDetails','shippingAddress'));
    }
    public function updateOrderStatus(Request $request){
        if($request->isMethod('post')){
            $data = $request->all();
            $order_id=$data['order_id'];
            Order::where(['id'=>$order_id])->update(['order_status'=>$data['status']]);
            return redirect()->back()->with('flash_message_success','order status updated');
        }
    }
    public function cancelOrder($id){
        Order::where(['id'=>$id])->delete();
        return redirect()->back()->with('flash_message_error','Order Cancelled');
    }
   
}
