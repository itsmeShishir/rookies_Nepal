<?php

namespace App\Http\Controllers;

use App\VendorOrder;
use Illuminate\Http\Request;

class VendorOrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\VendorOrder  $vendorOrder
     * @return \Illuminate\Http\Response
     */
    public function show(VendorOrder $vendorOrder)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\VendorOrder  $vendorOrder
     * @return \Illuminate\Http\Response
     */
    public function edit(VendorOrder $vendorOrder)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\VendorOrder  $vendorOrder
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, VendorOrder $vendorOrder)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\VendorOrder  $vendorOrder
     * @return \Illuminate\Http\Response
     */
    public function destroy(VendorOrder $vendorOrder)
    {
        //
    }
}
