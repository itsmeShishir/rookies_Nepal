<?php

namespace App\Http\Controllers;

use App\ContactTrioplus;
use App\Order;
use App\OrderProduct;
use App\User;
use Illuminate\Contracts\Session\Session as SessionSession;
use Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    public function login(Request $request){
        if($request->isMethod('post')){
            $data = $request->input();
            if(Auth::attempt(['email'=>$data['username'],'password'=>$data['password'],'role'=>'1'])){
                return redirect('admin/dashboard');
            }
            elseif(Auth::attempt(['email'=>$data['username'],'password'=>$data['password'],'role'=>'2'])){
                return redirect('admin/dashboard');
               
            } 
            else{
                return redirect('/trioadmin')->with('flash_message_error','Invalid Username and Password');
            }
        }
        return view('admin.admin_login');
    }
    public function vendors(){
        $vendors = User::where(['role'=>2])->get();
        return view('admin.users.vendor')->with(compact('vendors'));
    }
    public function registeredUsers(){
        $users = User::where(['role'=>3])->get();
        return view('admin.users.registered_users')->with(compact('users'));
    }
    public function dashboard(){
        if(Auth::user()->role == 2){
            $role = 'vendor';
            $totalClient = 0;
            $totalVendors = 0;
            $totalOrders = 0;
            $totalProductsSold = 0;
            return view('admin.dashboard')->with(compact('totalClient','totalVendors','totalOrders','totalProductsSold','role'));    
        }
        $totalClient = User::where(['role'=>3])->count();
        $totalVendors = User::where(['role'=>2])->count();
        $totalOrders = Order::count();
        $totalFeedbacks = ContactTrioplus::count();
        $totalProductsSold = OrderProduct::count();
        $role = 'admin';
        return view('admin.dashboard')->with(compact('totalClient','totalVendors','totalOrders','totalProductsSold','role','totalFeedbacks'));
    }   
    public function logout(){
        Session::flush();
        return redirect('/trioadmin')->with('flash_message_success','logged out successfully');
    }
}
