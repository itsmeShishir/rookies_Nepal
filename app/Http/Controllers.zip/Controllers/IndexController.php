<?php

namespace App\Http\Controllers;

use App\Banner;
use App\Category;
use App\Product;
use App\ProductsAttribute;
use App\ProductsImage;
use Illuminate\Http\Request;
use App\Traits\HeaderHelper;

class IndexController extends Controller
{
    use HeaderHelper;
    public function index(){
       
        $banners = Banner::where(['status'=>1])->orderby('sort_order','asc')->get();
       
        $products = Product::paginate(8);
        $featuredProducts= Product::where(['featured'=>1])->get();
        $recentProducts= Product::orderBy('created_at','desc')->paginate(8);
        //for header section categories for search and cart item for cart modal 
        $cartItems = $this->categoryItems();
        $categories = $this->categoryList();
        //end of header section
        return view('shop.index',compact('banners','categories','products','featuredProducts','recentProducts','cartItems'));
    }
    public function product($id){
        $productImages = ProductsImage::where('product_id',$id)->get();
        $product = Product::with('attributes')->where(['id'=>$id])->get()->first();
        $featuredProducts= Product::where(['featured'=>1])->get();
       //for header section categories for search and cart item for cart modal 
       $cartItems = $this->categoryItems();
       $categories = $this->categoryList();
       //end of header section
        return view('shop.product_details')->with(compact('product','productImages','featuredProducts','categories','cartItems'));
    }
    public function categories($category_id){
        $categories = Category::with('categories')->where(['parent_id'=>0])->get();
        $products = Product::where(['category_id'=>$category_id])->get();
        $featuredProducts= Product::where(['featured'=>1])->get();
         //for header section categories for search and cart item for cart modal 
         $cartItems = $this->categoryItems();
         $categories = $this->categoryList();
         //end of header section
         $indexCategory = Category::where(['id'=>$category_id])->first();
         $categoryname = $indexCategory->name;
        return view('shop.categories')->with(compact('categories','products','featuredProducts','cartItems','categoryname'));
    }
    public function getPrice(Request $request){
        $data = $request->all();
        // echo "<pre"; print_r($data);die;
        $proArr = explode("--",$data['idSize']);
        $proAttr = ProductsAttribute::where(['product_id'=>$proArr[0],'size'=>$proArr[1]])->first();
        echo $proAttr->price;
    }
    public function getStock(Request $request){
        $data = $request->all();
        $product = Product::with('attributes')->where(['id'=>$data['product_id']])->first();
        $proArr = explode("--",$data['idSize']);
        foreach($product->attributes as $pro){
            if($pro->size == $proArr[1]){
                echo $pro->stock;
            }
        }
    }
}
